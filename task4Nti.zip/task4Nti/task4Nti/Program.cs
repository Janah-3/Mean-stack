﻿using System.Text.Json;
using MongoDB.Bson;
using MongoDB.Driver;

namespace task4Nti
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var client = new MongoClient("mongodb://localhost:27017");
            var database = client.GetDatabase("facultySystem2");

            // Get collection
            var students = database.GetCollection<BsonDocument>("students");

            // Insert document
            var student = new BsonDocument
        {
            { "studentId", "10" },
            { "firstName", "Sara" },
            { "lastName", "Ali" },
            { "email", "sara@gmail.com" },
            { "facultyId", 1 }
        };
            students.InsertOne(student);

            // Retrieve documents
            var allStudents = students.Find(new BsonDocument()).ToList();

            foreach (var s in allStudents)
            {
                Console.WriteLine(s.ToString());
            }
        }
    }
}
